
package hackathon;

import javax.swing.JFrame;


public class StartScreen extends javax.swing.JFrame {

    String name;
    public StartScreen() {
        initComponents();
        this.btnContinue.setVisible(false);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMain = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        btnEnter = new javax.swing.JButton();
        lblDate = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        lblDateAnswer = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAnswer = new javax.swing.JTextArea();
        btnContinue = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Respiratory Illness Tool");

        pnlMain.setBackground(new java.awt.Color(153, 153, 255));
        pnlMain.setLayout(null);

        lblTitle.setBackground(new java.awt.Color(204, 255, 204));
        lblTitle.setFont(new java.awt.Font("Tahoma", 1, 40)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("Respiratory Illness Tool");
        lblTitle.setToolTipText("");
        pnlMain.add(lblTitle);
        lblTitle.setBounds(270, 10, 488, 49);

        lblName.setBackground(new java.awt.Color(204, 255, 204));
        lblName.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblName.setForeground(new java.awt.Color(255, 255, 255));
        lblName.setText("Name:");
        pnlMain.add(lblName);
        lblName.setBounds(44, 146, 70, 29);

        txtName.setBackground(new java.awt.Color(204, 255, 204));
        txtName.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlMain.add(txtName);
        txtName.setBounds(144, 143, 410, 35);

        btnEnter.setBackground(new java.awt.Color(204, 255, 204));
        btnEnter.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btnEnter.setText("Enter");
        btnEnter.setOpaque(false);
        btnEnter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnterActionPerformed(evt);
            }
        });
        pnlMain.add(btnEnter);
        btnEnter.setBounds(590, 140, 152, 95);

        lblDate.setBackground(new java.awt.Color(204, 255, 204));
        lblDate.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblDate.setForeground(new java.awt.Color(255, 255, 255));
        lblDate.setText("Date:");
        pnlMain.add(lblDate);
        lblDate.setBounds(44, 205, 58, 29);

        txtDate.setBackground(new java.awt.Color(204, 255, 204));
        txtDate.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlMain.add(txtDate);
        txtDate.setBounds(144, 202, 410, 35);

        lblDateAnswer.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lblDateAnswer.setForeground(new java.awt.Color(255, 255, 255));
        pnlMain.add(lblDateAnswer);
        lblDateAnswer.setBounds(40, 490, 470, 40);

        txtAnswer.setEditable(false);
        txtAnswer.setBackground(new java.awt.Color(204, 255, 204));
        txtAnswer.setColumns(20);
        txtAnswer.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        txtAnswer.setLineWrap(true);
        txtAnswer.setRows(5);
        txtAnswer.setWrapStyleWord(true);
        txtAnswer.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane1.setViewportView(txtAnswer);

        pnlMain.add(jScrollPane1);
        jScrollPane1.setBounds(44, 293, 583, 168);

        btnContinue.setBackground(new java.awt.Color(204, 255, 204));
        btnContinue.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btnContinue.setText("Continue");
        btnContinue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnContinueActionPerformed(evt);
            }
        });
        pnlMain.add(btnContinue);
        btnContinue.setBounds(660, 360, 152, 95);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hackathon/4.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        pnlMain.add(jLabel1);
        jLabel1.setBounds(0, 0, 970, 580);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, 963, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, 572, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnterActionPerformed
      
        name = this.txtName.getText().trim();
        String date = this.txtDate.getText().trim();
        
        if (name.equals("") || date.equals("")) {
            lblDateAnswer.setText("Name or date is missing");
            return;
        }
        
        txtAnswer.setText("Welcome, " + name + " I hope you are doing well today. "
                + "Through a few steps, we will figure out your illness. Please click \"Continue\"");
        lblDateAnswer.setText(date);
        
        this.btnContinue.setVisible(true);
        
    }//GEN-LAST:event_btnEnterActionPerformed

    private void btnContinueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnContinueActionPerformed
        
        Analysis proj = new Analysis(name);
        proj.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnContinueActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StartScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StartScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StartScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StartScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StartScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnContinue;
    private javax.swing.JButton btnEnter;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblDateAnswer;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlMain;
    private javax.swing.JTextArea txtAnswer;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtName;
    // End of variables declaration//GEN-END:variables
}
