
package hackathon;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import javax.swing.JFrame;


public class Analysis extends javax.swing.JFrame {

   String [] influenza, covid, pneumonia, strepthroat, bronchitis, similar;
   double influenzaCounter, covidCounter, pneumoniaCounter, strepthroatCounter, bronchitisCounter, similarCounter;
   
   int arrayCounter = 0;
   String name;
   HashMap <String, String> questionSymptom = new HashMap <String, String>();
   
   
    public Analysis(String name) {
        this.name = name;
        initComponents();
        btnYes.setVisible(false);
        btnNo.setVisible(false);
        btnNotSure.setVisible(false);
        this.lblStatement.setText(" ");
        
        influenza = new String [] {"fever", "dry cough", "sore throat", "runny nose" , "body aches", "headaches",
        "tiredness", "vomiting", "seziures"};
        
        influenzaCounter = (double)influenza.length;
        
        covid = new String [] {"fever", "dry cough", "tiredness", "body aches", "sore throat", "diarrhea", "headaches",
        "loss of taste or smell", "rash", "discolouration of fingers or toes", "shortness of breath", "chest pain", 
        "loss of speech"};
        
        covidCounter = (double)covid.length;
        
        pneumonia = new String [] {"chest pain", "confusion in mental awareness", "wet cough", "tiredness", "fever", 
        "vomiting", "shortness of breath"};
        
        pneumoniaCounter = (double)pneumonia.length;
        
        strepthroat = new String [] {"sore throat", "difficulty swallowing", "fever", "swollen tonsils", "petichiae", 
        "swollen lymph nodes in neck"};
        
        strepthroatCounter = (double)strepthroat.length;
        
        bronchitis = new String [] {"wet cough", "chest pain", "headache", "sore throat", "fever"};
        
        bronchitisCounter = bronchitis.length;

        similar = new String [] {"fever", "dry cough", "sore throat", "runny nose" , "body aches", "headaches",
        "tiredness", "vomiting", "seziures", "diarrhea", "loss of taste or smell", "rash", "discolouration of fingers or toes"
        , "shortness of breath", "chest pain", "loss of speech","confusion in mental awareness", "wet cough", 
        "difficulty swallowing", "swollen tonsils", "petichiae", "swollen lymph nodes in neck"};
        
        similarCounter = similar.length;
        
        
    }
  
    
    void dispose (String name, double num, String disease) {
        EndScreen screen = new EndScreen (name, num, disease);
        screen.setVisible(true);
        this.dispose();
    }
    
    void disposalCheck () {
        if (arrayCounter == similar.length -1) {
            
            double a = influenzaCounter/influenza.length;
            double b = covidCounter/covid.length;
            double c = pneumoniaCounter/pneumonia.length;
            double d = strepthroatCounter/strepthroat.length;
            double e = bronchitisCounter/bronchitis.length;
            System.out.println(a + " " + b + " " + c + " " + d + " " + e);
            
            if (a>b && a>c && a>d && a>e) {
                dispose(name, a, "have Influenza");
            }
            else if (b>a && b>c && b>d && b>e) {
                dispose(name, b, "have Corona Virus");
            }
            else if (c>a && c>b && c>d && c>e) {
                dispose(name, c, "have Pneumonia");
            }
            else if (d>a && d>b && d>c && d>e) {
                dispose(name, d, "have Strep Throat");
            }
            else if (e>a && e>b && e>c && e>d) {
                dispose(name, e, "have Bronchitis");
            }
            else {
                dispose(name, e, "are fine, and may be thinking too much! Relax!");
            }
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMain = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        lblStatement = new javax.swing.JLabel();
        btnYes = new javax.swing.JButton();
        lblDateAnswer = new javax.swing.JLabel();
        btnNo = new javax.swing.JButton();
        btnNotSure = new javax.swing.JButton();
        btnStart = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Respiratory Illness Tool");
        getContentPane().setLayout(null);

        pnlMain.setBackground(new java.awt.Color(153, 153, 255));
        pnlMain.setLayout(null);

        lblTitle.setFont(new java.awt.Font("Tahoma", 1, 40)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("Analysis");
        lblTitle.setToolTipText("");
        pnlMain.add(lblTitle);
        lblTitle.setBounds(390, 20, 488, 49);

        lblStatement.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lblStatement.setForeground(new java.awt.Color(255, 255, 255));
        lblStatement.setText("Are you feeling sick?");
        pnlMain.add(lblStatement);
        lblStatement.setBounds(20, 130, 950, 30);

        btnYes.setBackground(new java.awt.Color(204, 255, 204));
        btnYes.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btnYes.setText("Yes");
        btnYes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYesActionPerformed(evt);
            }
        });
        pnlMain.add(btnYes);
        btnYes.setBounds(120, 240, 140, 47);

        lblDateAnswer.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlMain.add(lblDateAnswer);
        lblDateAnswer.setBounds(12, 565, 0, 0);

        btnNo.setBackground(new java.awt.Color(204, 255, 204));
        btnNo.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btnNo.setText("No");
        btnNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNoActionPerformed(evt);
            }
        });
        pnlMain.add(btnNo);
        btnNo.setBounds(720, 240, 140, 47);

        btnNotSure.setBackground(new java.awt.Color(204, 255, 204));
        btnNotSure.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btnNotSure.setText("Not sure");
        btnNotSure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNotSureActionPerformed(evt);
            }
        });
        pnlMain.add(btnNotSure);
        btnNotSure.setBounds(430, 400, 140, 47);

        btnStart.setBackground(new java.awt.Color(204, 255, 204));
        btnStart.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });
        pnlMain.add(btnStart);
        btnStart.setBounds(430, 240, 140, 47);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hackathon/4.png"))); // NOI18N
        pnlMain.add(jLabel1);
        jLabel1.setBounds(0, 0, 980, 590);

        getContentPane().add(pnlMain);
        pnlMain.setBounds(0, 0, 980, 590);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnYesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYesActionPerformed
        
       disposalCheck();
       
       for (int i = 0; i < influenza.length; i++) {
            if (influenza[i].equals(similar[arrayCounter])){
                influenzaCounter--;
            }
        }
       for (int i = 0; i < covid.length; i++) {
            if (covid[i].equals(similar[arrayCounter])){
                covidCounter--;
            }
        }
       for (int i = 0; i < pneumonia.length; i++) {
            if (pneumonia[i].equals(similar[arrayCounter])){
                pneumoniaCounter--;
            }
        }
       for (int i = 0; i < strepthroat.length; i++) {
            if (strepthroat[i].equals(similar[arrayCounter])){
                strepthroatCounter--;
            }
        }
       for (int i = 0; i < bronchitis.length; i++) {
            if (bronchitis[i].equals(similar[arrayCounter])){
                bronchitisCounter--;
            }
        }
       
       
       arrayCounter++;
       disposalCheck();
       
       this.lblStatement.setText("Are you experiencing " + similar[arrayCounter] + "?");

    }//GEN-LAST:event_btnYesActionPerformed

    private void btnNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNoActionPerformed
        disposalCheck();
        arrayCounter++;
        disposalCheck();
       
       this.lblStatement.setText("Are you experiencing " + similar[arrayCounter] + "?");
    }//GEN-LAST:event_btnNoActionPerformed

    private void btnNotSureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNotSureActionPerformed
        disposalCheck();
        arrayCounter++;
        disposalCheck();
       
       this.lblStatement.setText("Are you experiencing " + similar[arrayCounter] + "?");
    }//GEN-LAST:event_btnNotSureActionPerformed

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        btnStart.setVisible(false);
        btnYes.setVisible(true);
        btnNo.setVisible(true);
        btnNotSure.setVisible(true);
        this.lblStatement.setText("Are you experiencing " + similar[arrayCounter] + "?");
    }//GEN-LAST:event_btnStartActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Analysis.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Analysis.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Analysis.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Analysis.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        /*java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Analysis().setVisible(true);
            }
        });*/
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnNo;
    private javax.swing.JButton btnNotSure;
    private javax.swing.JButton btnStart;
    private javax.swing.JButton btnYes;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblDateAnswer;
    private javax.swing.JLabel lblStatement;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlMain;
    // End of variables declaration//GEN-END:variables
}
