
package hackathon;

import javax.swing.JFrame;


public class EndScreen extends javax.swing.JFrame {

    String name, disease;
    double num;
    public EndScreen(String name, double num, String disease) {
        initComponents();
        this.name = name;
        this.num = num;
        this.disease = disease;
        this.lblFinalStatement.setText(name + ", it seems you have " + disease);
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMain = new javax.swing.JPanel();
        lblConclusion = new javax.swing.JLabel();
        lblFinalStatement = new javax.swing.JLabel();
        lblDateAnswer = new javax.swing.JLabel();
        btnExit = new javax.swing.JButton();
        btnStartOver = new javax.swing.JButton();
        lblImage = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Respiratory Illness Tool");

        pnlMain.setBackground(new java.awt.Color(153, 153, 255));
        pnlMain.setLayout(null);

        lblConclusion.setFont(new java.awt.Font("Tahoma", 1, 40)); // NOI18N
        lblConclusion.setForeground(new java.awt.Color(255, 255, 255));
        lblConclusion.setText("Conclusion");
        lblConclusion.setToolTipText("");
        pnlMain.add(lblConclusion);
        lblConclusion.setBounds(360, 10, 488, 49);

        lblFinalStatement.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblFinalStatement.setForeground(new java.awt.Color(255, 255, 255));
        lblFinalStatement.setText("Name:");
        pnlMain.add(lblFinalStatement);
        lblFinalStatement.setBounds(20, 110, 910, 29);

        lblDateAnswer.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        pnlMain.add(lblDateAnswer);
        lblDateAnswer.setBounds(12, 598, 0, 0);

        btnExit.setBackground(new java.awt.Color(204, 255, 204));
        btnExit.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btnExit.setText("Exit");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });
        pnlMain.add(btnExit);
        btnExit.setBounds(117, 424, 152, 95);

        btnStartOver.setBackground(new java.awt.Color(204, 255, 204));
        btnStartOver.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btnStartOver.setText("Start Over");
        btnStartOver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartOverActionPerformed(evt);
            }
        });
        pnlMain.add(btnStartOver);
        btnStartOver.setBounds(600, 420, 152, 95);

        lblImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hackathon/4.png"))); // NOI18N
        pnlMain.add(lblImage);
        lblImage.setBounds(-40, -180, 1520, 940);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, 962, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, 573, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        System.exit(0);
   
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnStartOverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartOverActionPerformed
        StartScreen s = new StartScreen();
        s.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnStartOverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
       /* java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EndScreen().setVisible(true);
            }
        });*/
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnStartOver;
    private javax.swing.JLabel lblConclusion;
    private javax.swing.JLabel lblDateAnswer;
    private javax.swing.JLabel lblFinalStatement;
    private javax.swing.JLabel lblImage;
    private javax.swing.JPanel pnlMain;
    // End of variables declaration//GEN-END:variables
}
